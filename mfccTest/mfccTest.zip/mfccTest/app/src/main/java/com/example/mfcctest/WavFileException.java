package com.example.mfcctest;

public class WavFileException extends Exception {

    private static final long serialVersionUID = 1L;

    public WavFileException(final String message) {
        super(message);
    }

}
