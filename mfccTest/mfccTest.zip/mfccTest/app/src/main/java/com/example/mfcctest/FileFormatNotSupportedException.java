package com.example.mfcctest;

public class FileFormatNotSupportedException extends Exception {

    public FileFormatNotSupportedException(String message) {
        super(message);
    }

}